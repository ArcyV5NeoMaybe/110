USA MAP PACK

Files:
css/map.css
js/map.js
js/main.js
js/province.js
js/state.js
data/states.json
data/cities.json

Integration:
1. Add <link rel="stylesheet" href="css/map.css"> inside <head>.
2. Add <div id="usa-map-shell"></div> where the map should appear.
3. Add <script src="js/map.js"></script> before </body>.
4. Keep all files in the same folders shown here.

The map uses the U.S. state geometry from the us-atlas TopoJSON distribution, derived from U.S. Census Bureau cartographic boundaries. The browser creates 10 interactive province cells inside each state. This is a game abstraction, not real administrative subdivisions.

Province IDs use state abbreviations such as CA_01 and TX_01. The 10 province cells per state are gameplay abstractions generated inside the real state borders.
